# User Flows

## Student: Book & Complete a Paid Session
1. Register/login as a student.
2. Browse `/listings.php`, filter by category/price/rating.
3. Open a listing, pick an open time slot, choose "Pay" (demo payment).
4. Booking is created as `confirmed`, a `transactions` row is written, teacher is notified.
5. On session day, both parties open `/shared/meeting.php?id=BOOKING_ID`.
6. Teacher marks the booking `completed` from `/teacher/bookings.php`.
7. Student leaves a review from `/student/reviews.php` (only once, only after completion).

## Student: Barter Exchange
1. Add a skill to your profile (`/student/profile.php`) so you have something to offer.
2. Go to `/student/barter.php`, choose your skill, the skill you want, and a teacher who accepts
   barter.
3. Teacher receives the offer in `/teacher/barter.php`, can accept/reject.
4. Once accepted, a barter session is booked the same way as a paid one, with
   `payment_type=barter`, starting `pending` until the teacher confirms.

## Teacher: Create a Listing & Get Bookings
1. Register/login as a teacher, add your skills on `/teacher/profile.php`.
2. Create a listing on `/teacher/skill_form.php` (skill, price, level, duration, paid/barter).
3. Open `/teacher/availability.php` and add time slots for that listing.
4. Students book your slots; manage them from `/teacher/bookings.php`.
5. Share materials for a session from `/teacher/materials.php`.

## Employer: Find & Hire Talent
1. Register/login as an employer.
2. Search `/employer/find_talent.php` by skill, rating, or verification status.
3. Open a candidate's profile, click "Contact Candidate" with a position title and message.
4. Track the engagement in `/employer/hiring.php`, updating status as it progresses.
5. Once hired/completed, leave a review for the candidate.

## Admin: Verification & Moderation
1. Login as admin.
2. `/admin/verification.php` — review pending requests, approve/reject with notes. The user's
   `verification_status` updates immediately and they're notified.
3. `/admin/reports.php` — review open reports, take an action (no action / remove listing /
   deactivate user), permanently logged in `moderation_records`.
