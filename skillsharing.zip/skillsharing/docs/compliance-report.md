# Course Outline Compliance Report

**Course:** CSC 3215 Web Technologies, AIUB, Summer 2025–2026
**Source document analyzed:** `Summer_25_26_Web_Technologies_Course_Outline_3.pdf`

---

## 1. Required Language — Determined From the Outline

The course outline's Week 8–11 topic schedule (Section IX) explicitly names:

- Week 8: *"Introduction to PHP"*
- Week 9: *"PHP Form Submission, PHP Form validation"*
- Week 10: *"PHP Session and Cookie"*
- Week 11: *"PHP & MySQL, MVC"*

The reference textbook list (Section XVI) reinforces this: *PHP and MySQL Web Development*
(Welling & Thomson), *Beginning PHP5, Apache, and MySQL Web Development*, and the official
*PHP Documentation* (php.net). No other backend language or framework (Node.js, Python, Java,
Laravel, etc.) is mentioned anywhere in the outline.

**Conclusion: the required backend language is PHP, with MySQL as the database, in a simple
custom MVC structure — no framework.**

---

## 2. Compliance Checklist

| Course Outline Requirement | Original Project | Compliant? | Change Required |
|---|---|---|---|
| Backend language: **PHP** | Node.js + Express | ❌ Not Compliant | Rewrote entire backend in PHP 8 |
| Database: **MySQL** | SQLite (via `better-sqlite3`) | ❌ Not Compliant | Migrated schema + all queries to MySQL via PDO |
| PHP Sessions/Cookies (Week 10) | Express `express-session` | ❌ Not Compliant | Rebuilt auth on native PHP `$_SESSION` |
| PHP Form Submission/Validation (Week 9) | Express body-parsing + JS validation | ❌ Not Compliant | Rebuilt all forms as native PHP `$_POST` handling with server-side validation |
| PHP & MySQL, MVC (Week 11) | EJS templates + Express controllers, no MySQL | ❌ Not Compliant | Rebuilt as PHP pages (View) + `includes/functions.php` (Model/query layer) + per-page action scripts (Controller) |
| HTML/CSS/JavaScript (Weeks 2–6) | HTML/CSS/JS via EJS | ✅ Compliant | Kept as-is (same CSS file reused verbatim) |
| Secure auth / no plaintext passwords | bcrypt via `bcryptjs` | ✅ Compliant | Kept — now uses PHP's native `password_hash()`/`password_verify()` (bcrypt) |
| Relational database with real data storage | Real SQLite tables | ✅ Compliant (wrong DBMS) | Same relational design, ported to MySQL with proper FKs |
| No unnecessary frameworks | None used | ✅ Compliant | Preserved — no Laravel/Composer packages introduced |
| Same concept/features/pages/workflow | N/A (baseline) | — | **Unchanged** — every page, role, and feature from the original project is preserved 1:1 |

---

## 3. What Was NOT Changed

Per your instructions, these stayed exactly the same:
- The project concept (Skill-Sharing Management System) and all 4 user roles (Student, Teacher,
  Employer, Admin)
- Every page/feature: browsing/search/filter, wishlist, booking + demo payment, barter exchange,
  reviews, learning materials, verification workflow, hiring workflow, admin moderation/reports,
  notifications
- The visual design (the same CSS file was reused verbatim)
- The database's logical structure (same 18 tables, same relationships, same business rules —
  e.g. "can't review an incomplete session," "can't double-book a slot")
- The demo-payment and demo-meeting-room architecture (as originally scoped, not a real gateway/
  video SDK)

## 4. What Changed (Only Language/Tech, Not Concept)

- **Runtime:** Node.js → PHP 8
- **Web framework:** Express.js → none (plain PHP, per course scope — no framework is taught)
- **Templating:** EJS → native PHP templates (`<?php ?>` / `<?= ?>`)
- **Database:** SQLite → MySQL (schema translated: `AUTOINCREMENT`→`AUTO_INCREMENT`, SQLite
  `CHECK`-based enums → MySQL `ENUM`, `datetime('now')`→`CURRENT_TIMESTAMP`, etc.)
- **DB access layer:** `better-sqlite3` (synchronous JS) → PDO with prepared statements
  (parameterized, SQL-injection safe)
- **Sessions:** `express-session` (SQLite session store) → native PHP `$_SESSION`
- **Password hashing:** `bcryptjs` → PHP `password_hash()`/`password_verify()` (still bcrypt)
- **Routing:** Express route definitions → one PHP file per page/action (standard plain-PHP
  routing style, matching how the course teaches PHP without a router library)

---

## 5. Database Verification — Data Is Genuinely Stored

Every form was tested against the live MySQL database during development (not just checked in
the browser). Confirmed with direct `SELECT` queries after each action:

- **Registration** → row inserted into `users` (bcrypt hash confirmed to start with `$2y$`) and
  `user_profiles`.
- **Login** → validated against the stored hash; wrong password correctly rejected.
- **Teacher creates availability** → row inserted into `teacher_availability`.
- **Student books a session (paid)** → row inserted into `bookings`, the matching
  `teacher_availability` row flipped to `is_booked = 1` (inside a transaction, preventing double
  booking), and a `transactions` row created with a generated demo-payment reference.
- **Teacher marks a session completed** → `bookings.status` updated to `completed`.
- **Student reviews a completed session** → row inserted into `reviews`; a second attempt at
  reviewing the same session was correctly blocked (no duplicate row).
- **Student adds to wishlist** → row inserted into `wishlists`.
- **Verification request + admin approval** → row inserted into `verification_requests`, then
  updated by the admin action, with `users.verification_status` updated in the same transaction
  and a `notifications` row created.

All of the above were re-verified after the PHP/MySQL rebuild specifically (not carried over
assumptions from the previous Node/SQLite version).

---

## 6. How to Run the Project Locally

See `docs/setup-guide.md` for full steps. Summary:

```bash
mysql -u root -e "CREATE DATABASE skillshare CHARACTER SET utf8mb4;"
mysql -u root skillshare < database/schema.sql
cp .env.example .env
php database/seed.php
php -S localhost:8000
```

Demo login: any of `student@example.com` / `teacher@example.com` / `employer@example.com` /
`admin@example.com`, password `Demo@1234`.
