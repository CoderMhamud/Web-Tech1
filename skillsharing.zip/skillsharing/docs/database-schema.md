# Database Schema (MySQL)

Engine: **MySQL** (InnoDB, utf8mb4). Built from `database/schema.sql`. 18 tables.

## Entity Overview

| Table | Purpose |
|---|---|
| `users` | Core account record for all 4 roles. Stores bcrypt password hash, role, active flag, verification status. |
| `user_profiles` | 1-to-1 extended profile info (bio, headline, education, experience, company name). |
| `categories` | Skill categories. |
| `skills` | Individual skills, each belonging to a category. |
| `user_skills` | Many-to-many: which skills a user has and at what proficiency. |
| `skill_listings` | A teacher's marketplace listing (price, level, duration, paid/barter flags, status). |
| `teacher_availability` | Bookable time slots for a listing. |
| `bookings` | A student's booking of a slot (payment type, status, meeting info). |
| `learning_materials` | Resources shared by a teacher, tied to a booking. |
| `wishlists` | Students' saved listings. |
| `transactions` | Demo payment records tied to bookings (reference only — never raw card data). |
| `barter_exchanges` | Skill-for-skill exchange offers. |
| `reviews` | Ratings/comments tied to a completed `booking` or a `hiring_record`. |
| `verification_requests` | Verification requests + admin decision trail. |
| `hiring_records` | Employer-to-candidate hiring engagement + status lifecycle. |
| `reports` | User-submitted content/user reports. |
| `moderation_records` | Admin action log against a report (append-only history). |
| `notifications` | In-app notifications per user. |

## Key Relationships

- `users (1) — (1) user_profiles`
- `users (1) — (M) skill_listings` (as teacher)
- `users (M) — (M) skills` via `user_skills`
- `skill_listings (1) — (M) teacher_availability`
- `teacher_availability (1) — (0..1) bookings`
- `users (1) — (M) bookings` (separately as student and as teacher)
- `bookings (1) — (M) learning_materials`
- `bookings (1) — (0..1) reviews` (enforced by `UNIQUE(booking_id, reviewer_id)`)
- `bookings (1) — (0..1) transactions`
- `users (1) — (M) barter_exchanges` (as sender and as receiver)
- `reports (1) — (M) moderation_records`

## Constraints & Integrity

- All foreign keys declared with `FOREIGN KEY ... REFERENCES` and appropriate `ON DELETE` actions
  (`CASCADE` for dependent rows, `SET NULL` where the parent is optional context).
- `ENUM` columns constrain `role`, `status`, `verification_status`, `level`, `payment_type`, etc.
  to valid values.
- `CHECK (rating BETWEEN 1 AND 5)` on `reviews`.
- `UNIQUE` constraints prevent duplicate emails, duplicate wishlist entries, duplicate user-skill
  pairs, duplicate reviews per booking, and duplicate category/skill names.
- **Double-booking prevention**: `student/booking_action.php` wraps the booking creation in a PDO
  transaction and performs `UPDATE teacher_availability SET is_booked = 1 WHERE id = ? AND
  is_booked = 0`. If a concurrent request already booked the slot, `rowCount()` is 0 and the
  transaction rolls back — verified live against MySQL during testing.
- Indexes on all frequently-filtered/joined columns (see bottom of `schema.sql`).

## Verified Data Flow (form → database)

Every form in the application was tested end-to-end against the live MySQL database (not just the
UI) during development:

| Form / Action | Table(s) written | Verified with |
|---|---|---|
| Register | `users`, `user_profiles` | `SELECT` after POST — bcrypt hash confirmed (`$2y$...`) |
| Login | reads `users`, sets PHP session | wrong-password rejection tested |
| Teacher: add availability | `teacher_availability` | row inspected after POST |
| Student: book session (paid) | `bookings`, `teacher_availability` (locked), `transactions` | all three inspected after POST |
| Teacher: complete session | `bookings.status` | `UPDATE` confirmed |
| Student: review | `reviews` | row + duplicate-block confirmed |
| Student: wishlist | `wishlists` | row confirmed |
| Any role: submit verification | `verification_requests`, `users.verification_status` | confirmed |
| Admin: approve verification | `verification_requests`, `users.verification_status`, `notifications` | confirmed |
