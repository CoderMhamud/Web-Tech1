# Page / Route Documentation

Plain PHP routing (no router library, per course scope): each page is its own `.php` file, with
sibling `*_action.php` files handling form POSTs and redirecting back. Protected pages call
`requireRole()` at the top (see `includes/functions.php`).

## Auth
| Method | Path | Description |
|---|---|---|
| GET/POST | `/auth/login.php` | Login form + authenticate |
| GET/POST | `/auth/register.php` | Registration form + create account |
| POST | `/auth/logout.php` | Destroy session |

## Public
| Path | Description |
|---|---|
| `/index.php` | Homepage |
| `/listings.php` | Browse/search/filter skill listings |
| `/listing.php?id=ID` | Listing detail + availability + reviews + booking form |

## Student (`requireRole('student')`)
| Path | Description |
|---|---|
| `/student/dashboard.php` | Overview |
| `/student/wishlist.php` + `/student/wishlist_action.php` | View / add / remove wishlist |
| `/student/bookings.php` + `/student/booking_action.php` | View / create / cancel / reschedule bookings |
| `/student/calendar.php` | Upcoming/past sessions |
| `/student/barter.php` + `/student/barter_action.php` | View / send / respond to barter offers |
| `/student/transactions.php` | Payment history |
| `/student/reviews.php` + `/student/review_action.php` | Reviewable sessions / submit review |
| `/student/materials.php` | Learning materials shared with this student |
| `/student/profile.php` + `/student/profile_action.php` | Profile, skills, password, verification |

## Teacher (`requireRole('teacher')`)
| Path | Description |
|---|---|
| `/teacher/dashboard.php` | Overview |
| `/teacher/skills.php` | List my listings |
| `/teacher/skill_form.php` (`?id=` for edit) + `/teacher/skill_action.php` | Create/update/delete listing |
| `/teacher/availability.php` + `/teacher/availability_action.php` | Create/delete availability |
| `/teacher/bookings.php` + `/teacher/booking_action.php` | Confirm/complete/cancel bookings |
| `/teacher/materials.php` + `/teacher/material_action.php` | Share/delete materials |
| `/teacher/transactions.php` | Earnings history |
| `/teacher/reviews.php` | Reviews received |
| `/teacher/barter.php` + `/teacher/barter_action.php` | Respond to barter offers |

## Employer (`requireRole('employer')`)
| Path | Description |
|---|---|
| `/employer/dashboard.php` | Overview |
| `/employer/find_talent.php` | Search/filter candidates |
| `/employer/candidate.php?id=ID` | Candidate profile |
| `/employer/hiring.php` + `/employer/hiring_action.php` | View/create engagement, update status |
| `/employer/reviews.php` + `/employer/review_action.php` | View/submit candidate review |

## Admin (`requireRole('admin')`)
| Path | Description |
|---|---|
| `/admin/dashboard.php` | Platform statistics |
| `/admin/users.php` + `/admin/user_action.php` | Manage users, toggle active |
| `/admin/skills.php` + `/admin/skill_action.php` | Manage skills & categories |
| `/admin/listings.php` + `/admin/listing_action.php` | All listings, remove |
| `/admin/verification.php` + `/admin/verification_action.php` | Approve/reject requests |
| `/admin/reports.php` + `/admin/report_action.php` | Resolve reports, moderation history |
| `/admin/transactions.php` | All platform transactions |

## Shared (any authenticated user)
| Path | Description |
|---|---|
| `/shared/meeting.php?id=BOOKING_ID` | Demo meeting room (participants only) |
| `/shared/notifications.php` | List + mark-read notifications |
| `/shared/report_action.php` | Submit a content/user report |
