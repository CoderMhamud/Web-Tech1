# Setup Guide

## Prerequisites
- PHP 8.0+ with `pdo_mysql` and `mbstring` extensions enabled
- MySQL 5.7+/8.0+ (or MariaDB)

## Step-by-step

1. **Unzip the project** and open a terminal in the project root (the folder containing this file
   and `index.php`).

2. **Create the database and user:**
   ```bash
   mysql -u root -e "CREATE DATABASE skillshare CHARACTER SET utf8mb4;"
   mysql -u root -e "CREATE USER 'skillshare_user'@'localhost' IDENTIFIED BY 'skillshare_pass';"
   mysql -u root -e "GRANT ALL PRIVILEGES ON skillshare.* TO 'skillshare_user'@'localhost'; FLUSH PRIVILEGES;"
   ```
   (Use your own credentials if preferred — just update `.env` in step 4 to match.)

3. **Import the schema:**
   ```bash
   mysql -u root skillshare < database/schema.sql
   ```

4. **Create your environment file:**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` if your DB host/user/password differ from the defaults.

5. **Seed demo data:**
   ```bash
   php database/seed.php
   ```
   This creates one demo user per role plus skills, listings, bookings, reviews, transactions,
   barter offers, verification requests, and hiring records.

6. **Run the app:**
   ```bash
   php -S localhost:8000
   ```
   Visit **http://localhost:8000**.

   **Using Apache/XAMPP/WAMP instead:** copy this folder into your web server's document root
   (e.g. `htdocs/skillshare`), make sure `pdo_mysql` and `mbstring` are enabled in `php.ini`, and
   set `BASE_URL=/skillshare` in `.env` if it's not served from the domain root.

7. **Login** with any demo account (see README section 6), or register a new one.

## Resetting Data
Re-run `php database/seed.php` at any time — it truncates every table and reseeds fresh demo data.

## Troubleshooting
- **"Database connection failed"** — check that MySQL is running and the credentials in `.env`
  match a real MySQL user with access to the `skillshare` database.
- **Blank page / 500 error** — check your PHP error log; the most common cause is a missing
  `pdo_mysql` or `mbstring` extension (`php -m` to list installed extensions).
