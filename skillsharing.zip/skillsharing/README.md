# Skill-Sharing Management System (PHP & MySQL Edition)

A full-stack web application for learning, teaching, and exchanging skills — built for
**CSC 3215: Web Technologies** (AIUB, Summer 2025–2026), rebuilt in **PHP + MySQL** to match
the course outline's required technology stack.

> This is a language-compliance conversion of the original project. The concept, pages, roles,
> features, and workflows are unchanged — see `docs/compliance-report.md` for the full
> before/after analysis and what specifically changed.

---

## 1. Technology Stack (per course outline)

- **Backend:** PHP 8 (procedural + a light custom MVC split: `includes/functions.php` acts as
  the Model layer for shared queries, each page is a Controller+View, `includes/*.php` are
  reusable View partials) — matches Weeks 8–11 of the syllabus (PHP, PHP forms, PHP sessions,
  **PHP & MySQL, MVC**).
- **Database:** MySQL, accessed via PDO with prepared statements everywhere (SQL-injection safe).
- **Frontend:** HTML, CSS, vanilla JavaScript (matches Weeks 2–6: HTML/DOM, CSS, JavaScript/ES6).
- **Sessions/Auth:** native PHP `$_SESSION` + `password_hash()`/`password_verify()` (bcrypt) —
  matches Week 10 (PHP Session and Cookie).
- No frameworks (Laravel, Composer packages, JS frameworks) are used, since none are required or
  taught in the outline.

---

## 2. Features

Same as the original build — see below, or `docs/user-flow.md` for full workflows:

- **All users:** registration/login (bcrypt), role-based dashboards, profile management,
  in-app notifications, verification requests, content reporting.
- **Student:** browse/search/filter listings, wishlist, book paid or barter sessions, manage/
  reschedule/cancel bookings, calendar, barter offers, transaction history, review completed
  sessions only (no duplicates), access learning materials.
- **Teacher:** create/edit/delete skill listings, manage availability (overlap + double-booking
  prevention), confirm/complete/cancel bookings, share learning materials, view earnings/reviews,
  respond to barter offers.
- **Employer:** search/filter skilled users, view candidate profiles, contact/hire candidates,
  track engagement status, review candidates after hiring.
- **Administrator:** platform dashboard/statistics, manage users (search/filter/activate/
  deactivate), manage skills & categories, moderate listings, review reports (with permanent
  moderation history), approve/reject verification requests, view all transactions.

---

## 3. Project Structure

```
skillshare-php/
├── index.php                  Homepage
├── listings.php                Browse/search/filter skill listings
├── listing.php                 Listing detail + booking form
├── auth/                       login.php, register.php, logout.php
├── student/                    dashboard, wishlist, bookings, calendar, barter, transactions,
│                                reviews, materials, profile + matching *_action.php handlers
├── teacher/                    dashboard, skills, skill_form, availability, bookings,
│                                materials, transactions, reviews, barter, profile + actions
├── employer/                   dashboard, find_talent, candidate, hiring, reviews, profile + actions
├── admin/                      dashboard, users, skills, listings, verification, reports,
│                                transactions, profile + actions
├── shared/                     meeting.php (demo video room), notifications.php, report_action.php
├── includes/                   functions.php (Model layer + helpers), header.php, footer.php,
│                                sidebar.php, alerts.php, profile_content.php, error_403/404.php
├── config/                     config.php (bootstraps .env/session/db), database.php (PDO)
├── database/                   schema.sql (MySQL DDL), seed.php (demo data via PDO)
├── assets/css/style.css        Styling (shared design system)
├── docs/                       database-schema.md, api-documentation.md (route map),
│                                user-flow.md, setup-guide.md, compliance-report.md
├── .env.example
└── README.md
```

---

## 4. Requirements

- PHP 8.0+ with the `pdo_mysql` and `mbstring` extensions
- MySQL 5.7+ / 8.0+ (or MariaDB equivalent)
- Apache or PHP's built-in server

---

## 5. Installation & Setup

```bash
# 1. Create the database and a dedicated user (adjust credentials as you like)
mysql -u root -e "CREATE DATABASE skillshare CHARACTER SET utf8mb4;"
mysql -u root -e "CREATE USER 'skillshare_user'@'localhost' IDENTIFIED BY 'skillshare_pass';"
mysql -u root -e "GRANT ALL PRIVILEGES ON skillshare.* TO 'skillshare_user'@'localhost'; FLUSH PRIVILEGES;"

# 2. Import the schema
mysql -u root skillshare < database/schema.sql

# 3. Configure environment
cp .env.example .env
# edit .env if your DB credentials differ from the defaults above

# 4. Seed realistic demo data
php database/seed.php

# 5. Run the app
php -S localhost:8000
```

Visit **http://localhost:8000**. (To deploy on Apache/XAMPP/WAMP instead: point the document
root at this folder, ensure `pdo_mysql` and `mbstring` are enabled in `php.ini`, and set
`BASE_URL` in `.env` to your subfolder path if not serving from the web root.)

To reset all data at any time: re-run `php database/seed.php` (it truncates and reseeds all
tables).

---

## 6. Demo Credentials

Password for every demo account: **`Demo@1234`**

| Role | Email |
|---|---|
| Student | student@example.com |
| Student 2 | tanvir.student@example.com |
| Teacher | teacher@example.com |
| Teacher 2 | nusrat.teacher@example.com |
| Teacher 3 (pending verification) | imran.teacher@example.com |
| Employer | employer@example.com |
| Admin | admin@example.com |

---

## 7. Database

18 tables covering users/profiles, skills/categories, listings, availability, bookings,
materials, wishlists, transactions, barter, reviews, verification, hiring, reports/moderation,
and notifications — full breakdown in `docs/database-schema.md`. All forms in the app write to
these tables via prepared PDO statements; nothing is faked on the frontend. See
`docs/compliance-report.md` for the specific INSERT/SELECT/UPDATE/DELETE verification performed
on this build.

---

## 8. Known Limitations

Unchanged from the original build (these are architectural choices allowed by the project brief,
not language-related gaps):
- Payments are a labeled demo flow (`includes/functions.php::processDemoPayment()`) — no real
  gateway, no card data ever stored.
- Video meetings use a demo meeting-room page (meeting ID + join button) rather than a real
  video SDK.
- Learning materials accept a resource URL rather than a binary file upload.

## 9. Future Improvements

- Real payment gateway (SSLCommerz/Stripe) and video provider integration
- Direct file uploads (`multer`-equivalent: PHP's `move_uploaded_file`)
- Pagination on large admin tables
- Automated tests (PHPUnit)
